import math as m
from java.lang import Math
def getDistanceBetweenPoints(pointA,pointB):
	if pointB[0] <> pointA[0] and pointB[1]<>pointA[1]:
		#return m.ceil(Math.sqrt(abs((pointB[0]-pointA[0])^2+(pointB[1]-pointA[1])^2)))
		return Math.sqrt(abs((pointB[0]-pointA[0])**2+(pointB[1]-pointA[1])**2))
	elif pointB[0] == pointA[0]:
		return abs(pointB[1]-pointA[1])
	elif pointB[1] == pointA[1]:
		return abs(pointB[0]-pointA[0])

# Granularity specifies how many points to generate by interval
def interpolatePoints(pointA,pointB,distance,granularity=1.0):

	newPointList=[]
	if pointB[0] <> pointA[0]:
		ratio = abs(float(pointB[1]-pointA[1])/(pointB[0]-pointA[0]))
	else:
		ratio = 1.0
	
#	print "ratio", ratio
	widthOfRun = abs(pointB[0]-pointA[0])	
	xMultiplier = 1
	yMultiplier = -1
	if pointB[0] < pointA[0]:
		xMultiplier = -1
	if pointB[1] > pointA[1]:
		yMultiplier = 1
#	print "interpolage range: ",  m.ceil(distance/granularity)
	for i in range(0, int(m.ceil(distance/granularity))):
		newX = pointA[0] + (i*(widthOfRun*(granularity/distance)))*xMultiplier
#		newY = pointA[1] + ((i*ratio)*granularity)/distance*yMultiplier
		newY = pointA[1] + ratio*abs(newX-pointA[0]) * yMultiplier
		newPointList.append((newX,newY))
	
	return newPointList
	
	